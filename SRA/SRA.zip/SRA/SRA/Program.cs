using System;
using System.Windows.Forms;

namespace SRA
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // A caixa modal permite que o SplashScreen seja desenhado e o timer execute normalmente.
            using (var splashScreen = new SplashScreen())
            {
                splashScreen.ShowDialog();
            }

            Application.Run(new PainelPrincipal());
        }
    }
}
