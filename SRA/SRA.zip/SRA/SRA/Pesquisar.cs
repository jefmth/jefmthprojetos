using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using SRA.Models;
using SRA.Services;

namespace SRA
{
    public partial class Pesquisar : Form
    {
        private sealed class ResultadoArquivo
        {
            public string Caminho;
            public string Nome;
            public List<AtaLinha> LinhasDaData;
            public List<AtaLinha> LinhasDoArquivo;
            public int TotalLinhas;
        }

        private readonly List<ResultadoArquivo> _arquivosEncontrados = new List<ResultadoArquivo>();
        private List<AtaLinha> _linhasEncontradas = new List<AtaLinha>();
        private DateTime _dataPesquisa;
        private string _tituloPdfPesquisa;
        private bool _atualizandoResultados;

        public Pesquisar()
        {
            InitializeComponent();
            dtpData.Value = DateTime.Today;
            dgvResultados.CellClick += dgvResultados_CellClick;
            dgvResultados.SelectionChanged += dgvResultados_SelectionChanged;
            EstilizarBotoes();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            _dataPesquisa = dtpData.Value.Date;
            _tituloPdfPesquisa = null;
            _arquivosEncontrados.Clear();
            _linhasEncontradas.Clear();
            _atualizandoResultados = true;
            dgvResultados.Rows.Clear();
            btnGerarPdf.Enabled = false;
            lblResultado.Text = "Pesquisando registros...";

            try
            {
                string pastaBanco = BancoJsonService.ObterPasta();
                string[] arquivos = Directory.GetFiles(pastaBanco, "*.json", SearchOption.AllDirectories);
                foreach (string arquivo in arquivos)
                {
                    try
                    {
                        AtaRegistro ata = BancoJsonService.Carregar(arquivo);
                        if (ata.Linhas == null) continue;
                        List<AtaLinha> linhasDaData = ata.Linhas.Where(l =>
                        {
                            DateTime dataLinha;
                            return DateTime.TryParseExact((l.Data ?? string.Empty).Trim(), "dd/MM/yyyy",
                                CultureInfo.InvariantCulture, DateTimeStyles.None, out dataLinha) &&
                                dataLinha.Date == _dataPesquisa;
                        }).ToList();

                        if (linhasDaData.Count == 0) continue;
                        _arquivosEncontrados.Add(new ResultadoArquivo
                        {
                            Caminho = arquivo,
                            Nome = string.IsNullOrWhiteSpace(ata.Nome) ? Path.GetFileNameWithoutExtension(arquivo) : ata.Nome,
                            LinhasDaData = linhasDaData,
                            // Preserva exatamente a sequência cronológica salva em Registrar.
                            LinhasDoArquivo = ata.Linhas.ToList(),
                            TotalLinhas = ata.Linhas.Count
                        });
                    }
                    catch
                    {
                        // Ignora JSON inválido e arquivos auxiliares no banco.
                    }
                }

                _arquivosEncontrados.Sort((a, b) => string.Compare(a.Nome, b.Nome, StringComparison.CurrentCultureIgnoreCase));
                foreach (ResultadoArquivo resultado in _arquivosEncontrados)
                {
                    int indice = dgvResultados.Rows.Add(
                        _dataPesquisa.ToString("dd/MM/yyyy"),
                        Path.GetFileName(resultado.Caminho),
                        resultado.Nome,
                        resultado.LinhasDaData.Count.ToString(CultureInfo.InvariantCulture),
                        resultado.TotalLinhas.ToString(CultureInfo.InvariantCulture),
                        resultado.Caminho,
                        null);
                    string imagem = resultado.LinhasDaData.Select(l => l.ImagemBase64)
                        .FirstOrDefault(x => !string.IsNullOrWhiteSpace(x));
                    if (!string.IsNullOrWhiteSpace(imagem))
                        dgvResultados.Rows[indice].Cells[colImagem.Index].Value = DecodificarImagem(imagem);
                }

                _atualizandoResultados = false;
                dgvResultados.ClearSelection();
                _linhasEncontradas.Clear();
                _tituloPdfPesquisa = null;
                btnGerarPdf.Enabled = false;
                lblResultado.Text = _arquivosEncontrados.Count == 0
                    ? "Nenhum arquivo de registro encontrado para " + _dataPesquisa.ToString("dd/MM/yyyy") + "."
                    : _arquivosEncontrados.Count + " arquivo(s) de registro encontrado(s) para " +
                      _dataPesquisa.ToString("dd/MM/yyyy") + ". Selecione um arquivo para exportar todas as suas linhas em PDF.";
            }
            catch (Exception ex)
            {
                _atualizandoResultados = false;
                lblResultado.Text = "Não foi possível pesquisar no banco JSON.";
                MessageBox.Show("Erro ao pesquisar os registros:\n" + ex.Message, "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvResultados_SelectionChanged(object sender, EventArgs e)
        {
            if (_atualizandoResultados || dgvResultados.SelectedRows.Count == 0) return;
            int indice = dgvResultados.SelectedRows[0].Index;
            if (indice < 0 || indice >= _arquivosEncontrados.Count) return;

            ResultadoArquivo selecionado = _arquivosEncontrados[indice];
            // A data filtra quais arquivos aparecem na lista, mas a exportação do arquivo
            // selecionado deve conter todas as linhas exatamente como o registro salvo.
            _linhasEncontradas = selecionado.LinhasDoArquivo;
            _tituloPdfPesquisa = "REGISTRO " + selecionado.Nome + " - " + _dataPesquisa.ToString("dd/MM/yyyy");
            btnGerarPdf.Enabled = _linhasEncontradas.Count > 0;
            lblResultado.Text = "Selecionado: " + Path.GetFileName(selecionado.Caminho) + " — " +
                _linhasEncontradas.Count + " acontecimento(s). O PDF conterá todas as linhas deste arquivo.";
        }

        private void EstilizarBotoes()
        {
            EstilizarBotao(btnPesquisar, Color.FromArgb(37, 99, 235));
            EstilizarBotao(btnGerarPdf, Color.FromArgb(15, 118, 110));
        }

        private static void EstilizarBotao(Button botao, Color cor)
        {
            botao.BackColor = cor;
            botao.ForeColor = Color.White;
            botao.FlatStyle = FlatStyle.Flat;
            botao.FlatAppearance.BorderSize = 0;
            botao.FlatAppearance.MouseOverBackColor = ControlPaint.Dark(cor, 0.08f);
            botao.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(cor, 0.18f);
            botao.Cursor = Cursors.Hand;
            botao.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            botao.Height = 40;
        }

        private void dgvResultados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != colImagem.Index) return;
            var imagem = dgvResultados.Rows[e.RowIndex].Cells[colImagem.Index].Value as Image;
            if (imagem == null) return;
            using (var janela = new Form())
            using (var visualizador = new PictureBox())
            {
                janela.Text = "Visualização da imagem";
                janela.StartPosition = FormStartPosition.CenterParent;
                janela.ClientSize = new Size(900, 650);
                janela.MinimumSize = new Size(400, 300);
                visualizador.Dock = DockStyle.Fill;
                visualizador.SizeMode = PictureBoxSizeMode.Zoom;
                visualizador.Image = (Image)imagem.Clone();
                janela.Controls.Add(visualizador);
                janela.ShowDialog(this);
                visualizador.Image.Dispose();
            }
        }

        private static Image DecodificarImagem(string base64)
        {
            byte[] bytes = Convert.FromBase64String(base64);
            using (var memoria = new MemoryStream(bytes))
            using (var imagem = Image.FromStream(memoria)) return (Image)imagem.Clone();
        }

        private void btnGerarPdf_Click(object sender, EventArgs e)
        {
            if (_linhasEncontradas.Count == 0) return;
            try
            {
                var colunas = new List<ColunaPdf>
                {
                    new ColunaPdf { Titulo = "Data", Largura = 12f, Centralizar = true },
                    new ColunaPdf { Titulo = "Horário", Largura = 9f, Centralizar = true },
                    new ColunaPdf { Titulo = "Fato/Acontecimento", Largura = 30f },
                    new ColunaPdf { Titulo = "Envolvidos", Largura = 16f },
                    new ColunaPdf { Titulo = "Operador/Gravação", Largura = 17f },
                    new ColunaPdf { Titulo = "Status/Observações", Largura = 22f }
                };
                var linhas = _linhasEncontradas.Select(l => new[]
                {
                    l.Data ?? string.Empty, l.Horario ?? string.Empty, l.FatoAcontecimento ?? string.Empty,
                    l.Envolvidos ?? string.Empty, l.OperadorGravacao ?? string.Empty,
                    l.StatusObservacoes ?? string.Empty, l.ImagemBase64 ?? string.Empty
                }).ToList();
                colunas.Add(new ColunaPdf { Titulo = "Imagem", Largura = 14f });
                string caminho = Path.Combine(Path.GetTempPath(),
                    "Registro_Pesquisado_" + _dataPesquisa.ToString("yyyyMMdd", CultureInfo.InvariantCulture) + "_" +
                    DateTime.Now.ToString("HHmmss", CultureInfo.InvariantCulture) + ".pdf");
                PdfAtaService.Gerar(caminho,
                    _tituloPdfPesquisa ?? ("PESQUISA DE ACONTECIMENTOS - " + _dataPesquisa.ToString("dd/MM/yyyy")), colunas, linhas);
                try { Process.Start(caminho); }
                catch
                {
                    MessageBox.Show("O PDF foi gerado, mas não foi possível abri-lo automaticamente.\n\n" + caminho,
                        "PDF gerado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao gerar o PDF: " + ex.Message, "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
