namespace SRA
{
    partial class Pesquisar
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlFiltro = new System.Windows.Forms.Panel();
            this.lblData = new System.Windows.Forms.Label();
            this.dtpData = new System.Windows.Forms.DateTimePicker();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlGrade = new System.Windows.Forms.Panel();
            this.dgvResultados = new System.Windows.Forms.DataGridView();
            this.colData = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHorario = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFato = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEnvolvidos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOperador = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colImagem = new System.Windows.Forms.DataGridViewImageColumn();
            this.pnlRodape = new System.Windows.Forms.Panel();
            this.btnGerarPdf = new System.Windows.Forms.Button();
            this.pnlTopo.SuspendLayout();
            this.pnlFiltro.SuspendLayout();
            this.pnlGrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).BeginInit();
            this.pnlRodape.SuspendLayout();
            this.SuspendLayout();
            // pnlTopo
            this.pnlTopo.Controls.Add(this.lblTitulo);
            this.pnlTopo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopo.Size = new System.Drawing.Size(1280, 70);
            // lblTitulo
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitulo.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.Text = "Pesquisa de Acontecimentos";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // pnlFiltro
            this.pnlFiltro.Controls.Add(this.lblData);
            this.pnlFiltro.Controls.Add(this.dtpData);
            this.pnlFiltro.Controls.Add(this.btnPesquisar);
            this.pnlFiltro.Controls.Add(this.lblResultado);
            this.pnlFiltro.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlFiltro.Size = new System.Drawing.Size(1280, 90);
            this.pnlFiltro.Padding = new System.Windows.Forms.Padding(25, 10, 25, 10);
            // lblData
            this.lblData.AutoSize = true;
            this.lblData.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.lblData.Location = new System.Drawing.Point(30, 19);
            this.lblData.Text = "Data:";
            // dtpData
            this.dtpData.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpData.CustomFormat = "dd/MM/yyyy";
            this.dtpData.Location = new System.Drawing.Point(85, 16);
            this.dtpData.Name = "dtpData";
            this.dtpData.Size = new System.Drawing.Size(145, 22);
            // btnPesquisar
            this.btnPesquisar.BackColor = System.Drawing.Color.DarkBlue;
            this.btnPesquisar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPesquisar.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnPesquisar.ForeColor = System.Drawing.Color.White;
            this.btnPesquisar.Location = new System.Drawing.Point(245, 11);
            this.btnPesquisar.Size = new System.Drawing.Size(125, 34);
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = false;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // lblResultado
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Arial", 9.5F);
            this.lblResultado.Location = new System.Drawing.Point(30, 55);
            this.lblResultado.Text = "Selecione uma data e clique em Pesquisar.";
            // pnlGrade
            this.pnlGrade.Controls.Add(this.dgvResultados);
            this.pnlGrade.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlGrade.Padding = new System.Windows.Forms.Padding(25, 8, 25, 12);
            // dgvResultados
            this.dgvResultados.AllowUserToAddRows = false;
            this.dgvResultados.AllowUserToDeleteRows = false;
            this.dgvResultados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResultados.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvResultados.BackgroundColor = System.Drawing.Color.White;
            this.dgvResultados.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvResultados.ReadOnly = true;
            this.dgvResultados.RowHeadersVisible = false;
            this.dgvResultados.RowTemplate.MinimumHeight = 60;
            this.dgvResultados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colData, this.colHorario, this.colFato, this.colEnvolvidos, this.colOperador, this.colStatus, this.colImagem });
            this.dgvResultados.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 10F);
            this.dgvResultados.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvResultados.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgvResultados.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.dgvResultados.ColumnHeadersHeight = 34;
            this.dgvResultados.Name = "dgvResultados";
            this.dgvResultados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvResultados.GridColor = System.Drawing.Color.Black;
            this.dgvResultados.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Single;
            this.dgvResultados.Columns[0].HeaderText = "Data";
            this.dgvResultados.Columns[1].HeaderText = "Arquivo JSON";
            this.dgvResultados.Columns[2].HeaderText = "Nome do registro";
            this.dgvResultados.Columns[3].HeaderText = "Acontecimentos na data";
            this.dgvResultados.Columns[4].HeaderText = "Linhas no arquivo";
            this.dgvResultados.Columns[5].HeaderText = "Caminho do arquivo";
            this.dgvResultados.Columns[0].FillWeight = 12F;
            this.dgvResultados.Columns[1].FillWeight = 22F;
            this.dgvResultados.Columns[2].FillWeight = 22F;
            this.dgvResultados.Columns[3].FillWeight = 14F;
            this.dgvResultados.Columns[4].FillWeight = 14F;
            this.dgvResultados.Columns[5].FillWeight = 26F;
            this.colImagem.HeaderText = "Imagem";
            this.colImagem.Name = "colImagem";
            this.colImagem.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.colImagem.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colImagem.Width = 120;
            this.colImagem.MinimumWidth = 100;
            this.colImagem.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // colunas
            this.colData.Name = "colData";
            this.colHorario.Name = "colHorario";
            this.colFato.Name = "colFato";
            this.colEnvolvidos.Name = "colEnvolvidos";
            this.colOperador.Name = "colOperador";
            this.colStatus.Name = "colStatus";
            // pnlRodape
            this.pnlRodape.Controls.Add(this.btnGerarPdf);
            this.pnlRodape.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlRodape.Size = new System.Drawing.Size(1280, 70);
            // btnGerarPdf
            this.btnGerarPdf.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.btnGerarPdf.BackColor = System.Drawing.Color.Firebrick;
            this.btnGerarPdf.Enabled = false;
            this.btnGerarPdf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGerarPdf.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnGerarPdf.ForeColor = System.Drawing.Color.White;
            this.btnGerarPdf.Location = new System.Drawing.Point(1125, 16);
            this.btnGerarPdf.Size = new System.Drawing.Size(130, 38);
            this.btnGerarPdf.Text = "Gerar PDF";
            this.btnGerarPdf.UseVisualStyleBackColor = false;
            this.btnGerarPdf.Click += new System.EventHandler(this.btnGerarPdf_Click);
            // Pesquisar
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1280, 620);
            this.Controls.Add(this.pnlGrade);
            this.Controls.Add(this.pnlRodape);
            this.Controls.Add(this.pnlFiltro);
            this.Controls.Add(this.pnlTopo);
            this.MinimumSize = new System.Drawing.Size(900, 420);
            this.Name = "Pesquisar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pesquisa de Acontecimentos";
            this.pnlTopo.ResumeLayout(false);
            this.pnlFiltro.ResumeLayout(false);
            this.pnlFiltro.PerformLayout();
            this.pnlGrade.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).EndInit();
            this.pnlRodape.ResumeLayout(false);
            this.ResumeLayout(false);
        }
        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlFiltro;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.DateTimePicker dtpData;
        private System.Windows.Forms.Button btnPesquisar;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Panel pnlGrade;
        private System.Windows.Forms.DataGridView dgvResultados;
        private System.Windows.Forms.DataGridViewTextBoxColumn colData;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHorario;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFato;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEnvolvidos;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOperador;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatus;
        private System.Windows.Forms.DataGridViewImageColumn colImagem;
        private System.Windows.Forms.Panel pnlRodape;
        private System.Windows.Forms.Button btnGerarPdf;
    }
}
