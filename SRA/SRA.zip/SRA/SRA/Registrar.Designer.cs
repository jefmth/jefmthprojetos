namespace SRA
{
    partial class Registrar
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlRodape = new System.Windows.Forms.Panel();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnGerarPdf = new System.Windows.Forms.Button();
            this.pnlTabela = new System.Windows.Forms.Panel();
            this.dgvAta = new System.Windows.Forms.DataGridView();
            this.colHorario = new SRA.Controles.ColunaHora();
            this.colData = new SRA.Controles.ColunaData();
            this.colFato = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEnvolvidos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOperador = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colImagem = new System.Windows.Forms.DataGridViewImageColumn();
            this.pnlTopo.SuspendLayout();
            this.pnlTabela.SuspendLayout();
            this.pnlRodape.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAta)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.Controls.Add(this.lblTitulo);
            this.pnlTopo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopo.Location = new System.Drawing.Point(0, 0);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(1280, 70);
            this.pnlTopo.TabIndex = 0;
            // 
            // lblTitulo
            // 
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitulo.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.Black;
            this.lblTitulo.Location = new System.Drawing.Point(0, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(1280, 70);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "ATA DE REGISTRO CRONOLÓGICO DE ACONTECIMENTOS - SEGURANÇA";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlRodape
            // 
            this.pnlRodape.Controls.Add(this.btnLimpar);
            this.pnlRodape.Controls.Add(this.btnSalvar);
            this.pnlRodape.Controls.Add(this.btnEditar);
            this.pnlRodape.Controls.Add(this.btnGerarPdf);
            this.pnlRodape.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlRodape.Location = new System.Drawing.Point(0, 550);
            this.pnlRodape.Name = "pnlRodape";
            this.pnlRodape.Size = new System.Drawing.Size(1280, 70);
            this.pnlRodape.TabIndex = 2;
            //
            // btnLimpar
            //
            this.btnLimpar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLimpar.BackColor = System.Drawing.Color.DimGray;
            this.btnLimpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimpar.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.White;
            this.btnLimpar.Location = new System.Drawing.Point(745, 16);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(120, 38);
            this.btnLimpar.TabIndex = 3;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            //
            // 
            // btnSalvar
            // 
            this.btnSalvar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSalvar.BackColor = System.Drawing.Color.Green;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvar.ForeColor = System.Drawing.Color.White;
            this.btnSalvar.Location = new System.Drawing.Point(875, 16);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(120, 38);
            this.btnSalvar.TabIndex = 0;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = false;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEditar.BackColor = System.Drawing.Color.DarkBlue;
            this.btnEditar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditar.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditar.ForeColor = System.Drawing.Color.White;
            this.btnEditar.Location = new System.Drawing.Point(1005, 16);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(120, 38);
            this.btnEditar.TabIndex = 1;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseVisualStyleBackColor = false;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnGerarPdf
            // 
            this.btnGerarPdf.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGerarPdf.BackColor = System.Drawing.Color.Firebrick;
            this.btnGerarPdf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGerarPdf.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGerarPdf.ForeColor = System.Drawing.Color.White;
            this.btnGerarPdf.Location = new System.Drawing.Point(1135, 16);
            this.btnGerarPdf.Name = "btnGerarPdf";
            this.btnGerarPdf.Size = new System.Drawing.Size(120, 38);
            this.btnGerarPdf.TabIndex = 2;
            this.btnGerarPdf.Text = "Gerar PDF";
            this.btnGerarPdf.UseVisualStyleBackColor = false;
            this.btnGerarPdf.Click += new System.EventHandler(this.btnGerarPdf_Click);
            // 
            // pnlTabela
            // 
            this.pnlTabela.BackColor = System.Drawing.Color.White;
            this.pnlTabela.Controls.Add(this.dgvAta);
            this.pnlTabela.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTabela.Location = new System.Drawing.Point(0, 70);
            this.pnlTabela.Name = "pnlTabela";
            this.pnlTabela.Padding = new System.Windows.Forms.Padding(25, 10, 25, 15);
            this.pnlTabela.Size = new System.Drawing.Size(1280, 480);
            this.pnlTabela.TabIndex = 1;
            // 
            // dgvAta
            // 
            this.dgvAta.AllowUserToAddRows = true;
            this.dgvAta.AllowUserToDeleteRows = true;
            this.dgvAta.AllowUserToResizeRows = false;
            this.dgvAta.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAta.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvAta.BackgroundColor = System.Drawing.Color.White;
            this.dgvAta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvAta.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Single;
            this.dgvAta.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAta.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvAta.ColumnHeadersHeight = 34;
            this.dgvAta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvAta.RowTemplate.Height = 60;
            this.dgvAta.RowTemplate.MinimumHeight = 60;
            this.dgvAta.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colData,
            this.colHorario,
            this.colFato,
            this.colEnvolvidos,
            this.colOperador,
            this.colStatus,
            this.colImagem});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(230)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAta.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(230)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvAta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAta.EnableHeadersVisualStyles = false;
            this.dgvAta.GridColor = System.Drawing.Color.Black;
            this.dgvAta.Location = new System.Drawing.Point(25, 10);
            this.dgvAta.Name = "dgvAta";
            this.dgvAta.RowHeadersVisible = false;
            this.dgvAta.Size = new System.Drawing.Size(1230, 455);
            this.dgvAta.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.dgvAta.TabIndex = 0;
            // 
            // colHorario
            // 
            this.colHorario.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colHorario.DefaultCellStyle = dataGridViewCellStyle3;
            this.colHorario.Width = 80;
            this.colHorario.HeaderText = "Horário";
            this.colHorario.MinimumWidth = 60;
            this.colHorario.Name = "colHorario";
            this.colHorario.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colData
            // 
            this.colData.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colData.DefaultCellStyle = dataGridViewCellStyle3;
            this.colData.Width = 125;
            this.colData.HeaderText = "Data";
            this.colData.MinimumWidth = 60;
            this.colData.Name = "colData";
            this.colData.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colFato
            // 
            this.colFato.FillWeight = 30F;
            this.colFato.HeaderText = "Fato/Acontecimento";
            this.colFato.MinimumWidth = 60;
            this.colFato.Name = "colFato";
            this.colFato.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colEnvolvidos
            // 
            this.colEnvolvidos.FillWeight = 16F;
            this.colEnvolvidos.HeaderText = "Envolvidos";
            this.colEnvolvidos.MinimumWidth = 60;
            this.colEnvolvidos.Name = "colEnvolvidos";
            this.colEnvolvidos.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colOperador
            // 
            this.colOperador.FillWeight = 17F;
            this.colOperador.HeaderText = "Operador/Gravação";
            this.colOperador.MinimumWidth = 60;
            this.colOperador.Name = "colOperador";
            this.colOperador.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colStatus
            // 
            this.colStatus.FillWeight = 22F;
            this.colStatus.HeaderText = "Status/Observações";
            this.colStatus.MinimumWidth = 60;
            this.colStatus.Name = "colStatus";
            this.colStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colImagem
            //
            this.colImagem.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.colImagem.HeaderText = "Imagem";
            this.colImagem.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.colImagem.MinimumWidth = 100;
            this.colImagem.Name = "colImagem";
            this.colImagem.Width = 120;
            this.colImagem.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Registrar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1280, 620);
            this.Controls.Add(this.pnlTabela);
            this.Controls.Add(this.pnlRodape);
            this.Controls.Add(this.pnlTopo);
            this.MinimumSize = new System.Drawing.Size(900, 420);
            this.Name = "Registrar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registrar";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTabela.ResumeLayout(false);
            this.pnlRodape.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAta)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlRodape;
        private System.Windows.Forms.Panel pnlTabela;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnGerarPdf;
        private System.Windows.Forms.DataGridView dgvAta;
        private SRA.Controles.ColunaHora colHorario;
        private SRA.Controles.ColunaData colData;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFato;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEnvolvidos;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOperador;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatus;
        private System.Windows.Forms.DataGridViewImageColumn colImagem;
    }
}
