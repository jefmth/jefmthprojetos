using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace SRA
{
    public partial class PainelPrincipal : Form
    {
        public PainelPrincipal()
        {
            InitializeComponent();
            Icon iconeExecutavel = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            if (iconeExecutavel != null) Icon = iconeExecutavel;
            pnlFundo.SizeChanged += pnlFundo_SizeChanged;
            CentralizarTitulo();
            CarregarImagemDeFundo();
            AtualizarDataHora();
            timerRelogio.Start();
        }

        private void pnlFundo_SizeChanged(object sender, EventArgs e)
        {
            CentralizarTitulo();
        }

        private void CentralizarTitulo()
        {
            lblTituloSistema.SetBounds(0, 22, pnlFundo.ClientSize.Width, 48);
            lblTituloSistema.TextAlign = ContentAlignment.MiddleCenter;
            lblDataHora.SetBounds(0, 74, pnlFundo.ClientSize.Width, 30);
            lblDataHora.TextAlign = ContentAlignment.MiddleCenter;
        }

        private void TimerRelogio_Tick(object sender, EventArgs e)
        {
            AtualizarDataHora();
        }

        private void AtualizarDataHora()
        {
            lblDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy  HH:mm:ss");
        }

        private void CarregarImagemDeFundo()
        {
            string caminho = Path.Combine(Application.StartupPath, "Imagens", "divisão.png");
            if (File.Exists(caminho))
            {
                Image fundo = Image.FromFile(caminho);
                pnlFundo.BackgroundImage = fundo;
                pnlFundo.BackgroundImageLayout = ImageLayout.Zoom;
            }
        }

        private void SairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void RegistrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var registrarForm = new Registrar()) registrarForm.ShowDialog(this);
        }

        private void SobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var sobreForm = new SobreForm()) sobreForm.ShowDialog(this);
        }

        private void PesquisarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var pesquisarForm = new Pesquisar()) pesquisarForm.ShowDialog(this);
        }
    }
}
