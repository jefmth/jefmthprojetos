using System;
using System.Globalization;
using System.Windows.Forms;

namespace SRA.Controles
{
    // ------------------------------------------------------------------
    // Colunas de DataGridView com seletor de DATA (calendário) e HORA.
    // O valor é guardado na célula como texto: "dd/MM/yyyy" e "HH:mm".
    // ------------------------------------------------------------------

    public class ColunaData : DataGridViewColumn
    {
        public ColunaData() : base(new CelulaData()) { }

        public override DataGridViewCell CellTemplate
        {
            get { return base.CellTemplate; }
            set
            {
                if (value != null && !(value is CelulaData))
                {
                    throw new InvalidCastException("O modelo da célula deve ser CelulaData.");
                }
                base.CellTemplate = value;
            }
        }
    }

    public class ColunaHora : DataGridViewColumn
    {
        public ColunaHora() : base(new CelulaHora()) { }

        public override DataGridViewCell CellTemplate
        {
            get { return base.CellTemplate; }
            set
            {
                if (value != null && !(value is CelulaHora))
                {
                    throw new InvalidCastException("O modelo da célula deve ser CelulaHora.");
                }
                base.CellTemplate = value;
            }
        }
    }

    public abstract class CelulaDateTimePicker : DataGridViewTextBoxCell
    {
        public override Type ValueType
        {
            get { return typeof(string); }
        }

        public override void InitializeEditingControl(int rowIndex, object initialFormattedValue,
                                                      DataGridViewCellStyle dataGridViewCellStyle)
        {
            base.InitializeEditingControl(rowIndex, initialFormattedValue, dataGridViewCellStyle);

            var controle = DataGridView.EditingControl as EditorDateTimePicker;
            if (controle != null)
            {
                controle.Inicializar(initialFormattedValue as string);
            }
        }
    }

    public class CelulaData : CelulaDateTimePicker
    {
        public override Type EditType
        {
            get { return typeof(EditorData); }
        }
    }

    public class CelulaHora : CelulaDateTimePicker
    {
        public override Type EditType
        {
            get { return typeof(EditorHora); }
        }
    }

    public class EditorData : EditorDateTimePicker
    {
        public EditorData() : base("dd/MM/yyyy", false) { }
    }

    public class EditorHora : EditorDateTimePicker
    {
        public EditorHora() : base("HH:mm", true) { }
    }

    public class EditorDateTimePicker : DateTimePicker, IDataGridViewEditingControl
    {
        private readonly string _formato;
        private bool _inicializando;

        protected EditorDateTimePicker(string formato, bool usarSetas)
        {
            _formato = formato;
            Format = DateTimePickerFormat.Custom;
            CustomFormat = formato;
            ShowUpDown = usarSetas; // Data: calendário suspenso. Hora: campo com setas.
        }

        // Chamado quando a célula entra em modo de edição.
        public void Inicializar(string textoAtual)
        {
            DateTime valor;
            bool vazio = !TentarLer(textoAtual, out valor);
            if (vazio)
            {
                valor = DateTime.Now; // célula vazia: sugere data/hora atual
            }

            _inicializando = true;
            Value = valor;
            _inicializando = false;

            if (vazio && EditingControlDataGridView != null)
            {
                EditingControlValueChanged = true;
                EditingControlDataGridView.NotifyCurrentCellDirty(true);
            }
        }

        private bool TentarLer(string texto, out DateTime valor)
        {
            return DateTime.TryParseExact(texto, _formato, CultureInfo.InvariantCulture,
                                          DateTimeStyles.None, out valor);
        }

        // ----- IDataGridViewEditingControl -----

        public DataGridView EditingControlDataGridView { get; set; }

        public int EditingControlRowIndex { get; set; }

        public bool EditingControlValueChanged { get; set; }

        public Cursor EditingPanelCursor
        {
            get { return base.Cursor; }
        }

        public bool RepositionEditingControlOnValueChange
        {
            get { return false; }
        }

        public object EditingControlFormattedValue
        {
            get { return Value.ToString(_formato, CultureInfo.InvariantCulture); }
            set
            {
                DateTime valor;
                if (TentarLer(value as string, out valor))
                {
                    Value = valor;
                }
            }
        }

        public object GetEditingControlFormattedValue(DataGridViewDataErrorContexts context)
        {
            return EditingControlFormattedValue;
        }

        public void ApplyCellStyleToEditingControl(DataGridViewCellStyle dataGridViewCellStyle)
        {
            Font = dataGridViewCellStyle.Font;
        }

        public bool EditingControlWantsInputKey(Keys keyData, bool dataGridViewWantsInputKey)
        {
            switch (keyData & Keys.KeyCode)
            {
                case Keys.Left:
                case Keys.Up:
                case Keys.Down:
                case Keys.Right:
                case Keys.Home:
                case Keys.End:
                case Keys.PageDown:
                case Keys.PageUp:
                    return true;
                default:
                    return !dataGridViewWantsInputKey;
            }
        }

        public void PrepareEditingControlForEdit(bool selectAll)
        {
        }

        protected override void OnValueChanged(EventArgs eventargs)
        {
            if (!_inicializando)
            {
                EditingControlValueChanged = true;
                if (EditingControlDataGridView != null)
                {
                    EditingControlDataGridView.NotifyCurrentCellDirty(true);
                }
            }
            base.OnValueChanged(eventargs);
        }
    }
}
