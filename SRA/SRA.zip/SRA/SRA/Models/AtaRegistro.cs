using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace SRA.Models
{
    // Um registro (ata) completo, salvo como um arquivo .json
    public class AtaRegistro
    {
        [JsonProperty("nome")]
        public string Nome { get; set; }

        // Data da primeira linha da tabela (dd/MM/yyyy)
        [JsonProperty("data")]
        public string Data { get; set; }

        [JsonProperty("dataSalvamento")]
        public DateTime DataSalvamento { get; set; } = DateTime.Now;

        [JsonProperty("linhas")]
        public List<AtaLinha> Linhas { get; set; } = new List<AtaLinha>();
    }

    // Uma linha da tabela "ATA DE REGISTRO CRONOLÓGICO DE ACONTECIMENTOS"
    public class AtaLinha
    {
        [JsonProperty("data")]
        public string Data { get; set; }

        [JsonProperty("horario")]
        public string Horario { get; set; }

        [JsonProperty("fatoAcontecimento")]
        public string FatoAcontecimento { get; set; }

        [JsonProperty("envolvidos")]
        public string Envolvidos { get; set; }

        [JsonProperty("operadorGravacao")]
        public string OperadorGravacao { get; set; }

        [JsonProperty("statusObservacoes")]
        public string StatusObservacoes { get; set; }

        // Imagem JPEG redimensionada e codificada em Base64 para persistir no JSON.
        [JsonProperty("imagemBase64")]
        public string ImagemBase64 { get; set; }
    }
}
