using System;
using Newtonsoft.Json;

namespace SRA.Models
{
    public class Ocorrencia
    {
        [JsonProperty("id")]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [JsonProperty("data")]
        public string Data { get; set; }

        [JsonProperty("horario")]
        public string Horario { get; set; }

        [JsonProperty("supervisor")]
        public string Supervisor { get; set; }

        [JsonProperty("agente")]
        public string Agente { get; set; }

        [JsonProperty("turno")]
        public string Turno { get; set; }

        [JsonProperty("tipoOrientacao")]
        public string TipoOrientacao { get; set; }

        [JsonProperty("descricao")]
        public string Descricao { get; set; }

        [JsonProperty("dataRegistro")]
        public DateTime DataRegistro { get; set; } = DateTime.Now;

        // ⭐ CAMPO PARA EXPIRAÇÃO AUTOMÁTICA (5 anos)
        [JsonProperty("_expiresAt")]
        public long ExpiresAt
        {
            get { return DateTimeOffset.Now.AddYears(5).ToUnixTimeSeconds(); }
        }
    }
}