using System;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using SRA.Models;

namespace SRA.Services
{
    public class FirebaseService
    {
        private readonly string _baseUrl;
        private readonly WebClient _webClient;

        public FirebaseService()
        {
            _baseUrl = "https://tipo-de-ocorrencias-default-rtdb.firebaseio.com/";
            _webClient = new WebClient();
            _webClient.Encoding = Encoding.UTF8;
            _webClient.Headers[HttpRequestHeader.ContentType] = "application/json";
        }

        public async Task<bool> RegistrarOcorrenciaAsync(Ocorrencia ocorrencia)
        {
            try
            {
                var url = $"{_baseUrl}ocorrencias/{ocorrencia.Id}.json";
                var json = JsonConvert.SerializeObject(ocorrencia);

                await _webClient.UploadStringTaskAsync(new Uri(url), "PUT", json);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao conectar com Firebase: {ex.Message}", "Erro",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
    }
}