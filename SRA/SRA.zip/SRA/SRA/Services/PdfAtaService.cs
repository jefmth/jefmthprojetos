using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;

namespace SRA.Services
{
    // Descreve uma coluna da tabela que vai para o PDF
    public class ColunaPdf
    {
        public string Titulo { get; set; }
        public float Largura { get; set; }       // só a proporção importa
        public bool Centralizar { get; set; }
    }

    // Gera o PDF da ata (A4 paisagem) sem depender de nenhuma biblioteca externa.
    public static class PdfAtaService
    {
        private const float LarguraPagina = 842f;   // A4 paisagem em pontos
        private const float AlturaPagina = 595f;
        private const float Margem = 36f;
        private const float TopoTabela = 82f;
        private const float RodapeY = 565f;          // posição do texto do rodapé (a partir do topo)
        private const float LimiteInferior = 548f;   // a tabela não passa daqui
        private const float AlturaCabecalho = 24f;
        private const float AlturaMinimaLinha = 42f;
        private const float Recuo = 4f;              // espaço interno das células
        private const float TamanhoTexto = 9f;
        private const float EntreLinhas = 11.5f;
        private const float AlturaLogo = 30f;

        private static readonly Encoding Latin = Encoding.GetEncoding(1252);

        public static void Gerar(string caminho, string titulo,
                                 IList<ColunaPdf> colunas, IList<string[]> linhas)
        {
            using (var bmp = new Bitmap(1, 1))
            using (Graphics g = Graphics.FromImage(bmp))
            using (var fonteNormal = new Font("Arial", TamanhoTexto, FontStyle.Regular, GraphicsUnit.Point))
            using (var fonteNegrito = new Font("Arial", TamanhoTexto, FontStyle.Bold, GraphicsUnit.Point))
            {
                g.PageUnit = GraphicsUnit.Point;

                // ---- larguras das colunas, ajustadas à largura útil da página ----
                float somaLarguras = 0;
                foreach (ColunaPdf c in colunas) somaLarguras += c.Largura;
                float larguraUtil = LarguraPagina - 2 * Margem;
                var larguras = new float[colunas.Count];
                for (int i = 0; i < colunas.Count; i++)
                {
                    larguras[i] = colunas[i].Largura / somaLarguras * larguraUtil;
                }

                // Fotos JPEG embutidas nas linhas; o conteúdo Base64 permanece fora do texto.
                var imagensPdf = new Dictionary<string, PdfImagem>();
                // ---- 1ª passada: quebra o texto e calcula a altura de cada linha ----
                float areaMaxima = LimiteInferior - TopoTabela - AlturaCabecalho;
                var textos = new List<List<string>[]>();
                var alturas = new List<float>();

                foreach (string[] linha in linhas)
                {
                    var celulas = new List<string>[colunas.Count];
                    int maxLinhas = 1;
                    for (int i = 0; i < colunas.Count; i++)
                    {
                        string valor = i < linha.Length ? (linha[i] ?? string.Empty).Trim() : string.Empty;
                        if (string.Equals(colunas[i].Titulo, "Imagem", StringComparison.OrdinalIgnoreCase))
                        {
                            celulas[i] = new List<string>();
                            if (!string.IsNullOrWhiteSpace(valor) && !imagensPdf.ContainsKey(valor))
                            {
                                byte[] jpeg = Convert.FromBase64String(valor);
                                using (var streamImagem = new MemoryStream(jpeg))
                                using (var image = Image.FromStream(streamImagem))
                                    imagensPdf.Add(valor, new PdfImagem { Bytes = jpeg, Largura = image.Width, Altura = image.Height, Nome = "ImFoto" + imagensPdf.Count });
                            }
                        }
                        else
                        {
                            celulas[i] = Quebrar(g, fonteNormal, valor, larguras[i] - 2 * Recuo);
                            if (celulas[i].Count > maxLinhas) maxLinhas = celulas[i].Count;
                        }
                    }
                    bool possuiImagem = false;
                    for (int i = 0; i < colunas.Count && i < linha.Length; i++)
                        if (string.Equals(colunas[i].Titulo, "Imagem", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrWhiteSpace(linha[i])) possuiImagem = true;
                    float altura = Math.Max(Math.Max(AlturaMinimaLinha, maxLinhas * EntreLinhas + 2 * Recuo), possuiImagem ? 72f : 0f);
                    textos.Add(celulas);
                    alturas.Add(Math.Min(altura, areaMaxima));
                }

                // ---- divide em páginas ----
                var paginas = new List<List<int>>();
                var atual = new List<int>();
                float y = TopoTabela + AlturaCabecalho;
                for (int r = 0; r < textos.Count; r++)
                {
                    if (atual.Count > 0 && y + alturas[r] > LimiteInferior)
                    {
                        paginas.Add(atual);
                        atual = new List<int>();
                        y = TopoTabela + AlturaCabecalho;
                    }
                    atual.Add(r);
                    y += alturas[r];
                }
                paginas.Add(atual); // sempre existe ao menos uma página (mesmo sem linhas)

                // ---- logotipo (discreto, canto superior esquerdo) ----
                byte[] logoJpeg = null;
                int logoLargPx = 0, logoAltPx = 0;
                CarregarLogo(out logoJpeg, out logoLargPx, out logoAltPx);

                // ---- monta o conteúdo de cada página ----
                float tamanhoTitulo = 14f;
                var conteudos = new List<string>();
                for (int p = 0; p < paginas.Count; p++)
                {
                    var sb = new StringBuilder();

                    if (logoJpeg != null)
                    {
                        float h = AlturaLogo;
                        float w = h * logoLargPx / logoAltPx;
                        sb.Append("q /GS1 gs ")
                          .Append(N(w)).Append(" 0 0 ").Append(N(h)).Append(' ')
                          .Append(N(Margem)).Append(' ').Append(N(AlturaPagina - Margem - h))
                          .Append(" cm /Im1 Do Q\n");
                    }

                    // título centralizado (reduz a fonte se não couber)
                    float larguraTitulo;
                    using (var ft = new Font("Arial", tamanhoTitulo, FontStyle.Bold, GraphicsUnit.Point))
                    {
                        larguraTitulo = Largura(g, ft, titulo);
                    }
                    float tamanho = tamanhoTitulo;
                    float disponivel = larguraUtil - 2 * (AlturaLogo * 1.2f + 10);
                    while (larguraTitulo > disponivel && tamanho > 8f)
                    {
                        tamanho -= 0.5f;
                        using (var ft = new Font("Arial", tamanho, FontStyle.Bold, GraphicsUnit.Point))
                        {
                            larguraTitulo = Largura(g, ft, titulo);
                        }
                    }
                    Texto(sb, (LarguraPagina - larguraTitulo) / 2f, Margem + 20f, titulo, true, tamanho, 0f);

                    // cabeçalho da tabela
                    float x = Margem;
                    float yTopo = TopoTabela;
                    sb.Append("0.92 g ").Append(N(Margem)).Append(' ')
                      .Append(N(AlturaPagina - yTopo - AlturaCabecalho)).Append(' ')
                      .Append(N(larguraUtil)).Append(' ').Append(N(AlturaCabecalho)).Append(" re f 0 g\n");
                    sb.Append("0.6 w 0 G\n");
                    for (int i = 0; i < colunas.Count; i++)
                    {
                        Retangulo(sb, x, yTopo, larguras[i], AlturaCabecalho);
                        float lt = Largura(g, fonteNegrito, colunas[i].Titulo);
                        float tx = x + Math.Max(Recuo, (larguras[i] - lt) / 2f);
                        Texto(sb, tx, yTopo + 16f, colunas[i].Titulo, true, TamanhoTexto, 0f);
                        x += larguras[i];
                    }

                    // linhas da tabela
                    float yLinha = TopoTabela + AlturaCabecalho;
                    foreach (int r in paginas[p])
                    {
                        float altura = alturas[r];
                        x = Margem;
                        for (int i = 0; i < colunas.Count; i++)
                        {
                            Retangulo(sb, x, yLinha, larguras[i], altura);
                            if (string.Equals(colunas[i].Titulo, "Imagem", StringComparison.OrdinalIgnoreCase) && i < linhas[r].Length && !string.IsNullOrWhiteSpace(linhas[r][i]))
                            {
                                PdfImagem foto;
                                if (imagensPdf.TryGetValue(linhas[r][i], out foto))
                                {
                                    float maxW = larguras[i] - 2 * Recuo, maxH = altura - 2 * Recuo;
                                    float fator = Math.Min(maxW / foto.Largura, maxH / foto.Altura);
                                    float iw = foto.Largura * fator, ih = foto.Altura * fator;
                                    float ix = x + (larguras[i] - iw) / 2f;
                                    float iy = AlturaPagina - (yLinha + (altura - ih) / 2f) - ih;
                                    sb.Append("q ").Append(N(iw)).Append(" 0 0 ").Append(N(ih)).Append(' ').Append(N(ix)).Append(' ').Append(N(iy)).Append(" cm /").Append(foto.Nome).Append(" Do Q\n");
                                }
                            }

                            float yTexto = yLinha + Recuo + TamanhoTexto;
                            foreach (string trecho in textos[r][i])
                            {
                                if (yTexto > yLinha + altura - 2f) break; // não escapa da célula
                                float tx = x + Recuo;
                                if (colunas[i].Centralizar)
                                {
                                    tx = x + Math.Max(Recuo, (larguras[i] - Largura(g, fonteNormal, trecho)) / 2f);
                                }
                                Texto(sb, tx, yTexto, trecho, false, TamanhoTexto, 0f);
                                yTexto += EntreLinhas;
                            }
                            x += larguras[i];
                        }
                        yLinha += altura;
                    }

                    // rodapé
                    string geradoEm = "Gerado em " + DateTime.Now.ToString("dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                    Texto(sb, Margem, RodapeY, geradoEm, false, 8f, 0.45f);
                    string pagina = "Página " + (p + 1) + " de " + paginas.Count;
                    float lp;
                    using (var fr = new Font("Arial", 8f, FontStyle.Regular, GraphicsUnit.Point))
                    {
                        lp = Largura(g, fr, pagina);
                    }
                    Texto(sb, LarguraPagina - Margem - lp, RodapeY, pagina, false, 8f, 0.45f);

                    conteudos.Add(sb.ToString());
                }

                Montar(caminho, conteudos, logoJpeg, logoLargPx, logoAltPx, imagensPdf);
            }
        }

        // ------------------------------------------------------------------
        // Montagem do arquivo PDF
        // ------------------------------------------------------------------
        private sealed class PdfImagem
        {
            public byte[] Bytes;
            public int Largura;
            public int Altura;
            public string Nome;
            public int Objeto;
        }

        private static void Montar(string caminho, List<string> conteudos,
                                   byte[] logoJpeg, int logoLarg, int logoAlt, Dictionary<string, PdfImagem> imagens)
        {
            bool temLogo = logoJpeg != null;
            int primeiraPagina = temLogo ? 6 : 5;
            int primeiroObjetoImagem = primeiraPagina - 1 + conteudos.Count * 2 + 1;
            int totalObjetos = primeiraPagina - 1 + conteudos.Count * 2 + imagens.Count;

            var corpos = new Dictionary<int, byte[]>();

            // /OpenAction: abre o PDF com zoom de 80% (0.8)
            corpos[1] = Ascii("<< /Type /Catalog /Pages 2 0 R /OpenAction [3 0 R /XYZ null null 0.8] >>");

            var kids = new StringBuilder();
            for (int p = 0; p < conteudos.Count; p++)
            {
                kids.Append(primeiraPagina + 2 * p).Append(" 0 R ");
            }
            corpos[2] = Ascii("<< /Type /Pages /Count " + conteudos.Count + " /Kids [ " + kids + "] >>");

            corpos[3] = Ascii("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
            corpos[4] = Ascii("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");

            if (temLogo)
            {
                corpos[5] = Fluxo("<< /Type /XObject /Subtype /Image /Width " + logoLarg + " /Height " + logoAlt +
                                  " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " +
                                  logoJpeg.Length + " >>", logoJpeg);
            }

            int indiceObjetoImagem = primeiroObjetoImagem;
            foreach (PdfImagem foto in imagens.Values)
            {
                foto.Objeto = indiceObjetoImagem++;
                corpos[foto.Objeto] = Fluxo("<< /Type /XObject /Subtype /Image /Width " + foto.Largura + " /Height " + foto.Altura +
                    " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + foto.Bytes.Length + " >>", foto.Bytes);
            }
            var xobjects = new StringBuilder("/XObject << ");
            if (temLogo) xobjects.Append("/Im1 5 0 R ");
            foreach (PdfImagem foto in imagens.Values) xobjects.Append('/').Append(foto.Nome).Append(' ').Append(foto.Objeto).Append(" 0 R ");
            xobjects.Append(">> ");
            string recursos = "/Resources << /Font << /F1 3 0 R /F2 4 0 R >> " +
                              (temLogo || imagens.Count > 0 ? xobjects.ToString() : "") +
                              "/ExtGState << /GS1 << /ca 0.55 >> >> >>";

            for (int p = 0; p < conteudos.Count; p++)
            {
                int objPagina = primeiraPagina + 2 * p;
                int objConteudo = objPagina + 1;

                corpos[objPagina] = Ascii("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + (int)LarguraPagina + " " +
                                          (int)AlturaPagina + "] " + recursos + " /Contents " + objConteudo + " 0 R >>");

                byte[] dados = Latin.GetBytes(conteudos[p]);
                corpos[objConteudo] = Fluxo("<< /Length " + dados.Length + " >>", dados);
            }

            using (var ms = new MemoryStream())
            {
                Escrever(ms, new byte[] { 0x25, 0x50, 0x44, 0x46, 0x2D, 0x31, 0x2E, 0x34, 0x0A,
                                          0x25, 0xE2, 0xE3, 0xCF, 0xD3, 0x0A }); // %PDF-1.4 + marca binária

                var posicoes = new long[totalObjetos + 1];
                for (int n = 1; n <= totalObjetos; n++)
                {
                    posicoes[n] = ms.Position;
                    Escrever(ms, Ascii(n + " 0 obj\n"));
                    Escrever(ms, corpos[n]);
                    Escrever(ms, Ascii("\nendobj\n"));
                }

                long inicioXref = ms.Position;
                var xref = new StringBuilder();
                xref.Append("xref\n0 ").Append(totalObjetos + 1).Append('\n');
                xref.Append("0000000000 65535 f \n");
                for (int n = 1; n <= totalObjetos; n++)
                {
                    xref.Append(posicoes[n].ToString("D10", CultureInfo.InvariantCulture)).Append(" 00000 n \n");
                }
                xref.Append("trailer\n<< /Size ").Append(totalObjetos + 1).Append(" /Root 1 0 R >>\n");
                xref.Append("startxref\n").Append(inicioXref).Append("\n%%EOF\n");
                Escrever(ms, Ascii(xref.ToString()));

                File.WriteAllBytes(caminho, ms.ToArray());
            }
        }

        private static byte[] Fluxo(string dicionario, byte[] dados)
        {
            using (var ms = new MemoryStream())
            {
                Escrever(ms, Ascii(dicionario + "\nstream\n"));
                Escrever(ms, dados);
                Escrever(ms, Ascii("\nendstream"));
                return ms.ToArray();
            }
        }

        private static void Escrever(Stream s, byte[] dados)
        {
            s.Write(dados, 0, dados.Length);
        }

        private static byte[] Ascii(string texto)
        {
            return Encoding.ASCII.GetBytes(texto);
        }

        // ------------------------------------------------------------------
        // Desenho
        // ------------------------------------------------------------------
        private static string N(float valor)
        {
            return valor.ToString("0.###", CultureInfo.InvariantCulture);
        }

        // yTopo = distância a partir do topo da página
        private static void Retangulo(StringBuilder sb, float x, float yTopo, float largura, float altura)
        {
            sb.Append(N(x)).Append(' ').Append(N(AlturaPagina - yTopo - altura)).Append(' ')
              .Append(N(largura)).Append(' ').Append(N(altura)).Append(" re S\n");
        }

        // yBase = posição da linha de base do texto, a partir do topo da página
        private static void Texto(StringBuilder sb, float x, float yBase, string texto,
                                  bool negrito, float tamanho, float cinza)
        {
            sb.Append(N(cinza)).Append(" g BT /").Append(negrito ? "F2 " : "F1 ").Append(N(tamanho)).Append(" Tf ")
              .Append(N(x)).Append(' ').Append(N(AlturaPagina - yBase)).Append(" Td (")
              .Append(Escapar(texto)).Append(") Tj ET 0 g\n");
        }

        private static string Escapar(string texto)
        {
            var sb = new StringBuilder();
            foreach (char c in texto ?? string.Empty)
            {
                if (c == '\\' || c == '(' || c == ')') sb.Append('\\').Append(c);
                else if (c < ' ') sb.Append(' ');
                else sb.Append(c);
            }
            return sb.ToString();
        }

        // ------------------------------------------------------------------
        // Medição e quebra de texto (Arial tem as mesmas medidas da Helvetica)
        // ------------------------------------------------------------------
        private static float Largura(Graphics g, Font fonte, string texto)
        {
            if (string.IsNullOrEmpty(texto)) return 0f;
            return g.MeasureString(texto, fonte, 100000, StringFormat.GenericTypographic).Width;
        }

        private static List<string> Quebrar(Graphics g, Font fonte, string texto, float larguraMax)
        {
            var resultado = new List<string>();
            if (string.IsNullOrEmpty(texto)) return resultado;

            string[] paragrafos = texto.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string paragrafo in paragrafos)
            {
                string atual = string.Empty;
                foreach (string bruta in paragrafo.Replace('\t', ' ').Split(' '))
                {
                    string palavra = bruta;
                    if (palavra.Length == 0) continue;

                    // palavra maior que a célula: corta em pedaços
                    while (palavra.Length > 1 && Largura(g, fonte, palavra) > larguraMax)
                    {
                        int n = 1;
                        while (n < palavra.Length - 1 && Largura(g, fonte, palavra.Substring(0, n + 1)) <= larguraMax) n++;
                        if (atual.Length > 0) { resultado.Add(atual); atual = string.Empty; }
                        resultado.Add(palavra.Substring(0, n));
                        palavra = palavra.Substring(n);
                    }

                    string tentativa = atual.Length == 0 ? palavra : atual + " " + palavra;
                    if (atual.Length == 0 || Largura(g, fonte, tentativa) <= larguraMax)
                    {
                        atual = tentativa;
                    }
                    else
                    {
                        resultado.Add(atual);
                        atual = palavra;
                    }
                }
                resultado.Add(atual);
            }

            while (resultado.Count > 0 && resultado[resultado.Count - 1].Length == 0)
            {
                resultado.RemoveAt(resultado.Count - 1);
            }
            return resultado;
        }

        // ------------------------------------------------------------------
        // Logotipo embutido no programa (Imagens\M_bom2024.png)
        // ------------------------------------------------------------------
        private static void CarregarLogo(out byte[] jpeg, out int largura, out int altura)
        {
            jpeg = null;
            largura = 0;
            altura = 0;

            try
            {
                Assembly asm = Assembly.GetExecutingAssembly();
                string recurso = null;
                foreach (string nome in asm.GetManifestResourceNames())
                {
                    if (nome.EndsWith("M_bom2024.png", StringComparison.OrdinalIgnoreCase))
                    {
                        recurso = nome;
                        break;
                    }
                }
                if (recurso == null) return; // sem logo: o PDF sai igual, só sem a imagem

                using (Stream fluxo = asm.GetManifestResourceStream(recurso))
                using (var original = new Bitmap(fluxo))
                using (var plano = new Bitmap(original.Width, original.Height, PixelFormat.Format24bppRgb))
                {
                    using (Graphics gg = Graphics.FromImage(plano))
                    {
                        gg.Clear(Color.White);
                        gg.CompositingQuality = CompositingQuality.HighQuality;
                        gg.DrawImage(original, 0, 0, original.Width, original.Height);
                    }

                    using (var ms = new MemoryStream())
                    {
                        plano.Save(ms, ImageFormat.Jpeg);
                        jpeg = ms.ToArray();
                    }
                    largura = plano.Width;
                    altura = plano.Height;
                }
            }
            catch
            {
                jpeg = null; // qualquer falha na imagem não impede de gerar o PDF
            }
        }
    }
}