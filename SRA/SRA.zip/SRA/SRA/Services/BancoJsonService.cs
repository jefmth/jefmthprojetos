using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using SRA.Models;

namespace SRA.Services
{
    // Cuida da pasta "BANCO JSON" e da gravação dos registros em .json
    public static class BancoJsonService
    {
        public const string NomePasta = "BANCO JSON";

        // Devolve o caminho da pasta "BANCO JSON", criando-a se ainda não existir.
        public static string ObterPasta()
        {
            string pasta = Path.Combine(ObterPastaDoProjeto(), NomePasta);
            Directory.CreateDirectory(pasta); // não faz nada se já existir
            return pasta;
        }

        // Devolve BANCO JSON\ANO\MÊS para a data informada (ex.: BANCO JSON\2026\10),
        // criando as subpastas se ainda não existirem.
        public static string ObterPastaDoRegistro(DateTime data)
        {
            string pasta = Path.Combine(ObterPasta(),
                                        data.Year.ToString("0000", CultureInfo.InvariantCulture),
                                        data.Month.ToString("00", CultureInfo.InvariantCulture));
            Directory.CreateDirectory(pasta);
            return pasta;
        }

        // Procura a pasta do projeto (onde está o .csproj), subindo a partir de bin\Debug.
        // Se não achar (programa instalado), usa a pasta do próprio executável.
        private static string ObterPastaDoProjeto()
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            var dir = new DirectoryInfo(baseDir);

            for (int i = 0; i < 4 && dir != null; i++, dir = dir.Parent)
            {
                if (dir.GetFiles("*.csproj").Length > 0)
                {
                    return dir.FullName;
                }
            }
            return baseDir;
        }

        // Deixa o nome seguro para arquivo: espaços viram "_" e caracteres proibidos são removidos.
        public static string LimparNome(string nome)
        {
            if (string.IsNullOrWhiteSpace(nome))
            {
                return string.Empty;
            }

            // Lista explícita (regra do Windows) somada à do sistema
            char[] invalidos = (new string(Path.GetInvalidFileNameChars()) + "\\/:*?\"<>|").ToCharArray();
            var sb = new StringBuilder();

            foreach (char c in nome.Trim())
            {
                if (char.IsWhiteSpace(c))
                {
                    sb.Append('_');
                }
                else if (Array.IndexOf(invalidos, c) < 0)
                {
                    sb.Append(c);
                }
            }

            string resultado = Regex.Replace(sb.ToString(), "_{2,}", "_").Trim('_', '.');
            if (resultado.Length > 80)
            {
                resultado = resultado.Substring(0, 80).TrimEnd('_', '.');
            }
            return resultado;
        }

        // Formato: dia-mês-ano_nome_do_registro.json  (ex.: 25-10-2026_plantao_noite.json)
        public static string MontarNomeArquivo(DateTime data, string nome)
        {
            return data.ToString("dd-MM-yyyy", CultureInfo.InvariantCulture)
                   + "_" + LimparNome(nome) + ".json";
        }

        // Lê um registro salvo. Lança exceção se o arquivo não for um registro válido.
        public static AtaRegistro Carregar(string caminhoArquivo)
        {
            string json = File.ReadAllText(caminhoArquivo, Encoding.UTF8);
            var ata = JsonConvert.DeserializeObject<AtaRegistro>(json);

            if (ata == null || ata.Linhas == null ||
                (ata.Linhas.Count == 0 && string.IsNullOrEmpty(ata.Data)))
            {
                throw new InvalidDataException("O arquivo não tem o formato de um registro da ata.");
            }
            return ata;
        }

        public static void Salvar(AtaRegistro ata, string caminhoArquivo)
        {
            string json = JsonConvert.SerializeObject(ata, Formatting.Indented);
            File.WriteAllText(caminhoArquivo, json, new UTF8Encoding(false));
        }
    }
}
