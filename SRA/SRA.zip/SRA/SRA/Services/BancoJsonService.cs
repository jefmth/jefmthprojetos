using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Newtonsoft.Json;
using SRA.Models;

namespace SRA.Services
{
    // Cuida da pasta compartilhada "BANCO JSON" e da gravação dos registros em .json.
    public static class BancoJsonService
    {
        public const string NomePasta = "BANCO JSON";
        private const string NomeArquivoConfiguracao = "pasta_banco.txt";

        // Devolve a pasta compartilhada do Google Drive, solicitando sua seleção na primeira execução.
        public static string ObterPasta()
        {
            string pasta = CarregarPastaConfigurada();
            if (string.IsNullOrWhiteSpace(pasta) || !Directory.Exists(pasta))
                pasta = ConfigurarPastaDrive();
            Directory.CreateDirectory(pasta);
            return pasta;
        }

        private static string CarregarPastaConfigurada()
        {
            try
            {
                string arquivo = CaminhoConfiguracao();
                return File.Exists(arquivo) ? File.ReadAllText(arquivo, Encoding.UTF8).Trim() : null;
            }
            catch { return null; }
        }

        private static string CaminhoConfiguracao()
        {
            string pastaConfiguracao = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SRA");
            Directory.CreateDirectory(pastaConfiguracao);
            return Path.Combine(pastaConfiguracao, NomeArquivoConfiguracao);
        }

        private static string ConfigurarPastaDrive()
        {
            using (var dialogo = new FolderBrowserDialog())
            {
                dialogo.Description = "Selecione a pasta compartilhada do Google Drive onde o SRA guardará os registros. O programa criará nela a pasta 'BANCO JSON'.";
                dialogo.ShowNewFolderButton = true;
                if (dialogo.ShowDialog() != DialogResult.OK || string.IsNullOrWhiteSpace(dialogo.SelectedPath))
                    throw new OperationCanceledException("A configuração da pasta de dados foi cancelada. Selecione a pasta compartilhada do Google Drive para usar o SRA.");

                string pastaSelecionada = Path.GetFullPath(dialogo.SelectedPath);
                string pastaBanco = Path.Combine(pastaSelecionada, NomePasta);
                string pastaAntiga = Path.Combine(ObterPastaDoProjeto(), NomePasta);
                Directory.CreateDirectory(pastaBanco);
                ImportarArquivosLocais(pastaAntiga, pastaBanco);

                File.WriteAllText(CaminhoConfiguracao(), pastaBanco, new UTF8Encoding(false));
                MessageBox.Show(
                    "Pasta de dados configurada:\r\n" + pastaBanco + "\r\n\r\n" +
                    "Neste computador, o SRA passará a usar essa pasta. Repita a seleção nos outros computadores e escolha a mesma pasta compartilhada sincronizada pelo Google Drive.",
                    "SRA - Pasta compartilhada configurada", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return pastaBanco;
            }
        }

        // Copia apenas arquivos ainda inexistentes no destino, preservando dados já sincronizados.
        private static void ImportarArquivosLocais(string origem, string destino)
        {
            if (!Directory.Exists(origem) || MesmoCaminho(origem, destino)) return;
            foreach (string arquivoOrigem in Directory.GetFiles(origem, "*", SearchOption.AllDirectories))
            {
                string raiz = origem.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                string relativo = arquivoOrigem.Substring(raiz.Length)
                    .TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                string arquivoDestino = Path.Combine(destino, relativo);
                string pastaDestino = Path.GetDirectoryName(arquivoDestino);
                if (!string.IsNullOrEmpty(pastaDestino)) Directory.CreateDirectory(pastaDestino);
                if (!File.Exists(arquivoDestino)) File.Copy(arquivoOrigem, arquivoDestino);
            }
        }

        private static bool MesmoCaminho(string caminhoA, string caminhoB)
        {
            string a = Path.GetFullPath(caminhoA).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string b = Path.GetFullPath(caminhoB).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            return string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
        }

        // Devolve BANCO JSON\ANO\MÊS para a data informada (ex.: BANCO JSON\2026\10).
        public static string ObterPastaDoRegistro(DateTime data)
        {
            string pasta = Path.Combine(ObterPasta(),
                                        data.Year.ToString("0000", CultureInfo.InvariantCulture),
                                        data.Month.ToString("00", CultureInfo.InvariantCulture));
            Directory.CreateDirectory(pasta);
            return pasta;
        }

        // Procura a pasta do projeto para importar registros locais existentes durante a configuração.
        private static string ObterPastaDoProjeto()
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            var dir = new DirectoryInfo(baseDir);
            for (int i = 0; i < 4 && dir != null; i++, dir = dir.Parent)
                if (dir.GetFiles("*.csproj").Length > 0) return dir.FullName;
            return baseDir;
        }

        // Deixa o nome seguro para arquivo: espaços viram "_" e caracteres proibidos são removidos.
        public static string LimparNome(string nome)
        {
            if (string.IsNullOrWhiteSpace(nome)) return string.Empty;
            char[] invalidos = (new string(Path.GetInvalidFileNameChars()) + "\\/:*?\"<>|").ToCharArray();
            var sb = new StringBuilder();
            foreach (char c in nome.Trim())
            {
                if (char.IsWhiteSpace(c)) sb.Append('_');
                else if (Array.IndexOf(invalidos, c) < 0) sb.Append(c);
            }
            string resultado = Regex.Replace(sb.ToString(), "_{2,}", "_").Trim('_', '.');
            if (resultado.Length > 80) resultado = resultado.Substring(0, 80).TrimEnd('_', '.');
            return resultado;
        }

        // Formato: dia-mês-ano_nome_do_registro.json
        public static string MontarNomeArquivo(DateTime data, string nome)
        {
            return data.ToString("dd-MM-yyyy", CultureInfo.InvariantCulture)
                   + "_" + LimparNome(nome) + ".json";
        }

        // Lê um registro salvo. Lança exceção se o arquivo não for um registro válido.
        public static AtaRegistro Carregar(string caminhoArquivo)
        {
            string json = File.ReadAllText(caminhoArquivo, Encoding.UTF8);
            var ata = JsonConvert.DeserializeObject<AtaRegistro>(json);
            if (ata == null || ata.Linhas == null ||
                (ata.Linhas.Count == 0 && string.IsNullOrEmpty(ata.Data)))
                throw new InvalidDataException("O arquivo não tem o formato de um registro da ata.");
            return ata;
        }

        public static void Salvar(AtaRegistro ata, string caminhoArquivo)
        {
            string json = JsonConvert.SerializeObject(ata, Formatting.Indented);
            File.WriteAllText(caminhoArquivo, json, new UTF8Encoding(false));
        }
    }
}
