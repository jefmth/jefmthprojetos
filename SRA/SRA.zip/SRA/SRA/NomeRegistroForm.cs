using System;
using System.Drawing;
using System.Windows.Forms;
using SRA.Services;

namespace SRA
{
    // Caixa que pede o nome do registro antes de salvar (criada só por código)
    public class NomeRegistroForm : Form
    {
        private readonly DateTime _data;
        private readonly TextBox txtNome;
        private readonly Label lblArquivo;
        private readonly Button btnOk;
        private readonly Button btnCancelar;

        public string NomeRegistro { get; private set; }

        public NomeRegistroForm(DateTime data, string nomeInicial = null)
        {
            _data = data;

            Text = "Salvar registro";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(420, 170);
            Font = new Font("Arial", 9F);
            BackColor = Color.White;

            var lblNome = new Label
            {
                Text = "Nome do registro:",
                Location = new Point(20, 20),
                AutoSize = true
            };

            txtNome = new TextBox
            {
                Location = new Point(20, 42),
                Size = new Size(380, 23),
                MaxLength = 80
            };
            txtNome.TextChanged += (s, e) => AtualizarPrevia();

            lblArquivo = new Label
            {
                Location = new Point(20, 76),
                Size = new Size(380, 34),
                ForeColor = Color.DimGray
            };

            btnOk = new Button
            {
                Text = "Salvar",
                Location = new Point(215, 122),
                Size = new Size(90, 32),
                BackColor = Color.Green,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnOk.Click += BtnOk_Click;

            btnCancelar = new Button
            {
                Text = "Cancelar",
                Location = new Point(310, 122),
                Size = new Size(90, 32),
                DialogResult = DialogResult.Cancel
            };

            Controls.Add(lblNome);
            Controls.Add(txtNome);
            Controls.Add(lblArquivo);
            Controls.Add(btnOk);
            Controls.Add(btnCancelar);

            AcceptButton = btnOk;
            CancelButton = btnCancelar;
            ActiveControl = txtNome;

            if (!string.IsNullOrWhiteSpace(nomeInicial))
            {
                txtNome.Text = nomeInicial;
                txtNome.SelectAll();
            }

            AtualizarPrevia();
        }

        private void AtualizarPrevia()
        {
            string nome = BancoJsonService.LimparNome(txtNome.Text);
            if (nome.Length == 0)
            {
                nome = "(nome)";
            }
            lblArquivo.Text = "Será salvo como:\r\n" + BancoJsonService.MontarNomeArquivo(_data, nome);
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            if (BancoJsonService.LimparNome(txtNome.Text).Length == 0)
            {
                MessageBox.Show("Digite um nome para o registro.", "Aviso",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNome.Focus();
                return;
            }

            NomeRegistro = txtNome.Text.Trim();
            DialogResult = DialogResult.OK;
        }
    }
}
