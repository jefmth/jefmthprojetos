using System.Drawing;
using System.Windows.Forms;

namespace SRA
{
    public sealed class SobreForm : Form
    {
        public SobreForm()
        {
            Text = "Sobre o SRA";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(560, 410);
            BackColor = Color.White;
            Font = new Font("Segoe UI", 10F);

            try
            {
                Icon icone = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
                if (icone != null) Icon = icone;
            }
            catch
            {
                // A janela continua funcional se o executável não tiver um ícone associado.
            }

            var cabecalho = new Panel
            {
                Dock = DockStyle.Top,
                Height = 88,
                BackColor = Color.FromArgb(35, 32, 89)
            };
            var titulo = new Label
            {
                Text = "Sistema de Registro de Acontecimentos",
                Dock = DockStyle.Fill,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 17F, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter
            };
            cabecalho.Controls.Add(titulo);

            var apresentacao = new Label
            {
                Text = "O SRA foi desenvolvido para registrar, organizar e consultar acontecimentos de forma clara e cronológica.",
                Location = new Point(32, 116),
                Size = new Size(496, 56),
                Font = new Font("Segoe UI", 11F),
                ForeColor = Color.FromArgb(45, 45, 55),
                TextAlign = ContentAlignment.MiddleLeft
            };

            var recursosTitulo = new Label
            {
                Text = "Principais recursos",
                Location = new Point(32, 184),
                Size = new Size(496, 26),
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(35, 32, 89)
            };

            var recursos = new Label
            {
                Text = "• Registro de data, horário, fato, envolvidos, operador e observações.\n" +
                       "• Inclusão de imagens com visualização e armazenamento comprimido.\n" +
                       "• Pesquisa de registros e geração de documentos em PDF.",
                Location = new Point(32, 214),
                Size = new Size(496, 82),
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(55, 55, 65)
            };

            var armazenamento = new Label
            {
                Text = "Os registros são armazenados localmente em arquivos JSON na pasta “BANCO JSON” do projeto. Mantenha cópias de segurança dessa pasta.",
                Location = new Point(32, 306),
                Size = new Size(496, 54),
                Font = new Font("Segoe UI", 9.5F),
                ForeColor = Color.FromArgb(90, 90, 100)
            };

            var fechar = new Button
            {
                Text = "Fechar",
                Size = new Size(110, 36),
                Location = new Point(418, 362),
                BackColor = Color.FromArgb(35, 32, 89),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                DialogResult = DialogResult.OK,
                Cursor = Cursors.Hand
            };
            fechar.FlatAppearance.BorderSize = 0;
            AcceptButton = fechar;
            CancelButton = fechar;

            Controls.Add(apresentacao);
            Controls.Add(recursosTitulo);
            Controls.Add(recursos);
            Controls.Add(armazenamento);
            Controls.Add(fechar);
            Controls.Add(cabecalho);
        }
    }
}
