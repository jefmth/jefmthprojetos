using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace SRA
{
    public partial class SplashScreen : Form
    {
        public SplashScreen()
        {
            InitializeComponent();
            string caminho = Path.Combine(Application.StartupPath, "Imagens", "SRAcontecimentos.jpg");
            if (File.Exists(caminho)) picLogo.Image = Image.FromFile(caminho);
            Icon icone = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            if (icone != null) Icon = icone;
        }

        private void SplashScreen_Shown(object sender, EventArgs e)
        {
            timerFechar.Start();
        }

        private void timerFechar_Tick(object sender, EventArgs e)
        {
            timerFechar.Stop();
            Close();
        }
    }
}
