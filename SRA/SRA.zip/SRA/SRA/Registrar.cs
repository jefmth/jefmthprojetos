using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Windows.Forms;
using SRA.Models;
using SRA.Services;

namespace SRA
{
    public partial class Registrar : Form
    {
        // Registro carregado pelo botão Editar (vazio quando a tabela é um registro novo)
        private string _arquivoAberto;
        private string _nomeAberto;
        private Bitmap _imagemVazia;
        private bool _carregandoTabela;

        public Registrar()
        {
            InitializeComponent();

            // Evita que o DataGridViewImageCell mostre o X de erro nas linhas dinâmicas.
            // A célula vazia é desenhada pelo CellPainting com nosso ícone centralizado.
            _imagemVazia = new Bitmap(1, 1, PixelFormat.Format32bppArgb);
            _imagemVazia.MakeTransparent();
            colImagem.DefaultCellStyle.NullValue = _imagemVazia;
            colImagem.ValuesAreIcons = false;
            dgvAta.DataError += dgvAta_DataError;
            dgvAta.RowsAdded += dgvAta_RowsAdded;
            dgvAta.CellValueChanged += dgvAta_CellValueChanged;
            dgvAta.CellClick += dgvAta_CellClick;

            // Desliga/religa a linha de entrada para ela nascer com a altura configurada (60 px)
            dgvAta.CellMouseClick += dgvAta_CellMouseClick;
            dgvAta.CellPainting += dgvAta_CellPainting;
            EstilizarBotoes();
            dgvAta.AllowUserToAddRows = false;

            // Linhas em branco iniciais, como no modelo em papel
            for (int i = 0; i < QuantidadeLinhasIniciais; i++)
            {
                dgvAta.Rows.Add();
            }

            // Não usamos a linha especial do DataGridView: ela exibia o X padrão.
            // Novas linhas normais são criadas automaticamente quando a última é preenchida.
            dgvAta.AllowUserToAddRows = false;
        }

        private void dgvAta_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= dgvAta.Rows.Count ||
                e.ColumnIndex < 0 || e.ColumnIndex >= dgvAta.Columns.Count) return;

            DataGridViewCell celula = dgvAta.Rows[e.RowIndex].Cells[e.ColumnIndex];
            if (!string.IsNullOrWhiteSpace(Convert.ToString(celula.Value))) return;

            DateTime agora = DateTime.Now;
            if (e.ColumnIndex == colData.Index)
                celula.Value = agora.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            else if (e.ColumnIndex == colHorario.Index)
                celula.Value = agora.ToString("HH:mm", CultureInfo.InvariantCulture);
        }


        private void EstilizarBotoes()
        {
            EstilizarBotao(btnLimpar, System.Drawing.Color.FromArgb(100, 116, 139));
            EstilizarBotao(btnSalvar, System.Drawing.Color.FromArgb(22, 163, 74));
            EstilizarBotao(btnEditar, System.Drawing.Color.FromArgb(37, 99, 235));
            EstilizarBotao(btnGerarPdf, System.Drawing.Color.FromArgb(15, 118, 110));
        }

        private static void EstilizarBotao(Button botao, System.Drawing.Color cor)
        {
            botao.BackColor = cor;
            botao.ForeColor = System.Drawing.Color.White;
            botao.FlatStyle = FlatStyle.Flat;
            botao.FlatAppearance.BorderSize = 0;
            botao.FlatAppearance.MouseOverBackColor = ControlPaint.Dark(cor, 0.08f);
            botao.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(cor, 0.18f);
            botao.Cursor = Cursors.Hand;
            botao.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            botao.Height = 40;
        }

        // Permite colar texto na célula selecionada, inclusive se estiver vazia.
        // Todo o conteúdo (inclusive quebras de linha e tabulações) permanece nessa célula.
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.V) && dgvAta.ContainsFocus &&
                dgvAta.CurrentCell != null)
            {
                if (dgvAta.CurrentCell.OwningColumn == colData ||
                    dgvAta.CurrentCell.OwningColumn == colHorario)
                {
                    return true;
                }

                if (dgvAta.CurrentCell.OwningColumn == colImagem)
                {
                    try
                    {
                        int indiceLinha = dgvAta.CurrentCell.RowIndex;
                        Image imagemClipboard = Clipboard.GetImage();
                        if (imagemClipboard != null)
                        {
                            using (imagemClipboard)
                                SalvarImagemNaLinha(indiceLinha, imagemClipboard);
                        }
                        else if (Clipboard.ContainsFileDropList())
                        {
                            // No Explorer, Ctrl+C copia o arquivo como uma lista de caminhos (FileDrop).
                            var arquivos = Clipboard.GetFileDropList();
                            string arquivoImagem = arquivos.Cast<string>().FirstOrDefault(CaminhoEhImagem);
                            if (arquivoImagem == null)
                            {
                                MessageBox.Show("O item copiado não contém um arquivo de imagem compatível.",
                                    "Colar imagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                using (var imagemArquivo = Image.FromFile(arquivoImagem))
                                    SalvarImagemNaLinha(indiceLinha, imagemArquivo);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Copie uma imagem ou um arquivo de imagem no Explorador e cole na célula com Ctrl+V.",
                                "Colar imagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Não foi possível colar a imagem: " + ex.Message,
                            "Colar imagem", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    return true;
                }

                try
                {
                    string texto = Clipboard.GetText();
                    if (!string.IsNullOrEmpty(texto)) ColarTextoNaCelula(texto);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Não foi possível colar o texto da área de transferência: " + ex.Message,
                        "Colar texto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void ColarTextoNaCelula(string texto)
        {
            DataGridViewCell celulaSelecionada = dgvAta.CurrentCell;
            if (celulaSelecionada == null || celulaSelecionada.ReadOnly) return;
            dgvAta.EndEdit();
            celulaSelecionada.Value = texto;
        }

        // Mantida apenas por compatibilidade com chamadas antigas: new Registrar(usuario)
        public Registrar(string usuarioLogado) : this()
        {
        }

        private const int QuantidadeLinhasIniciais = 4;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            var resposta = MessageBox.Show(
                "Deseja realmente limpar todos os dados da planilha? Esta ação não pode ser desfeita.",
                "Confirmar limpeza", MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2);
            if (resposta != DialogResult.Yes)
            {
                return;
            }

            dgvAta.CancelEdit();
            dgvAta.Rows.Clear();
            for (int i = 0; i < QuantidadeLinhasIniciais; i++)
            {
                dgvAta.Rows.Add();
            }
            _arquivoAberto = null;
            _nomeAberto = null;
            Text = "Registrar";
        }
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            SalvarRegistro();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            EditarRegistro();
        }

        private void btnGerarPdf_Click(object sender, EventArgs e)
        {
            GerarPdfProvisorio();
        }

        // ------------------------------------------------------------------
        // GERAR PDF (provisório): A4 paisagem, com o título e a tabela da tela.
        // O arquivo vai para a pasta temporária e abre no leitor de PDF padrão.
        // ------------------------------------------------------------------
        private void GerarPdfProvisorio()
        {
            // Confirma a célula que ainda estiver sendo editada
            dgvAta.EndEdit();

            try
            {
                // Colunas na mesma ordem e proporção em que aparecem na tela
                List<DataGridViewColumn> colunasTela =
                    dgvAta.Columns.Cast<DataGridViewColumn>().OrderBy(c => c.DisplayIndex).ToList();

                var colunas = new List<ColunaPdf>();
                foreach (DataGridViewColumn c in colunasTela)
                {
                    colunas.Add(new ColunaPdf
                    {
                        Titulo = c.HeaderText,
                        Largura = c.Width,
                        Centralizar = (c == colData || c == colHorario)
                    });
                }

                // Todas as linhas da tabela (menos a linha de entrada)
                var linhas = new List<string[]>();
                foreach (DataGridViewRow row in dgvAta.Rows)
                {
                    if (row.IsNewRow)
                    {
                        continue;
                    }

                    var valores = new string[colunasTela.Count];
                    bool possuiConteudo = false;
                    for (int i = 0; i < colunasTela.Count; i++)
                    {
                        valores[i] = colunasTela[i] == colImagem
                            ? (CodificarImagem(ImagemDaCelula(row.Index)) ?? string.Empty)
                            : (Convert.ToString(row.Cells[colunasTela[i].Index].Value) ?? string.Empty).Trim();
                        if (!string.IsNullOrWhiteSpace(valores[i])) possuiConteudo = true;
                    }
                    if (possuiConteudo) linhas.Add(valores);
                }

                string caminho = Path.Combine(Path.GetTempPath(),
                    "ATA_provisoria_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".pdf");

                PdfAtaService.Gerar(caminho, lblTitulo.Text, colunas, linhas);

                try
                {
                    Process.Start(caminho);
                }
                catch (Exception)
                {
                    MessageBox.Show("O PDF foi gerado, mas não foi possível abri-lo automaticamente.\n\n" + caminho,
                                    "PDF gerado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao gerar o PDF: " + ex.Message, "Erro",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ------------------------------------------------------------------
        // SALVAR: BANCO JSON SRA\ANO\MÊS\dd-MM-yyyy_nome.json
        // ------------------------------------------------------------------
        private void SalvarRegistro()
        {
            // Confirma a célula que ainda estiver sendo editada
            dgvAta.EndEdit();

            // A data do registro vem da primeira célula abaixo de "Data"
            if (dgvAta.Rows.Count == 0 || dgvAta.Rows[0].IsNewRow)
            {
                MessageBox.Show("Preencha a primeira linha da tabela antes de salvar.", "Aviso",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewCell celulaData = dgvAta.Rows[0].Cells[colData.Index];
            string textoData = Convert.ToString(celulaData.Value) ?? string.Empty;

            DateTime data;
            if (!DateTime.TryParseExact(textoData, "dd/MM/yyyy", CultureInfo.InvariantCulture,
                                        DateTimeStyles.None, out data))
            {
                MessageBox.Show("Preencha a Data da primeira linha da tabela antes de salvar.", "Aviso",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dgvAta.CurrentCell = celulaData;
                return;
            }

            // Caixa para dar nome ao registro (se veio do Editar, já vem com o nome dele)
            string nome;
            using (var dialogo = new NomeRegistroForm(data, _nomeAberto))
            {
                if (dialogo.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }
                nome = dialogo.NomeRegistro;
            }

            try
            {
                // Cria BANCO JSON SRA\ANO\MÊS (se não existirem) conforme a data da primeira linha
                string pasta = BancoJsonService.ObterPastaDoRegistro(data);
                string caminho = Path.Combine(pasta, BancoJsonService.MontarNomeArquivo(data, nome));

                // Ao salvar o mesmo registro que foi aberto pelo Editar, não precisa perguntar
                bool mesmoArquivoAberto = _arquivoAberto != null &&
                    string.Equals(Path.GetFullPath(_arquivoAberto), Path.GetFullPath(caminho),
                                  StringComparison.OrdinalIgnoreCase);

                if (File.Exists(caminho) && !mesmoArquivoAberto)
                {
                    var resposta = MessageBox.Show(
                        "Já existe um registro com este nome:\n" + Path.GetFileName(caminho) +
                        "\n\nDeseja substituí-lo?",
                        "Registro existente", MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

                    if (resposta != DialogResult.Yes)
                    {
                        return;
                    }
                }

                var ata = new AtaRegistro
                {
                    Nome = nome,
                    Data = textoData,
                    DataSalvamento = DateTime.Now
                };
                ata.Linhas.AddRange(ColetarLinhas());

                BancoJsonService.Salvar(ata, caminho);

                MessageBox.Show("Registro salvo com sucesso!\n\n" + caminho, "Sucesso",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar o registro: " + ex.Message, "Erro",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ------------------------------------------------------------------
        // EDITAR: abre BANCO JSON SRA, o usuário escolhe o .json e ele sobe para a tabela
        // ------------------------------------------------------------------
        private void EditarRegistro()
        {
            dgvAta.EndEdit();

            string caminho;
            using (var dialogo = new OpenFileDialog())
            {
                dialogo.Title = "Selecione o registro que deseja editar";
                dialogo.InitialDirectory = BancoJsonService.ObterPasta(); // cria "BANCO JSON SRA" se não existir
                dialogo.Filter = "Registros JSON (*.json)|*.json";
                dialogo.RestoreDirectory = true;

                if (dialogo.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }
                caminho = dialogo.FileName;
            }

            AtaRegistro ata;
            try
            {
                ata = BancoJsonService.Carregar(caminho);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível abrir o registro:\n" + Path.GetFileName(caminho) +
                                "\n\n" + ex.Message, "Erro",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Se a tabela já tem dados, confirma antes de trocar
            if (ColetarLinhas().Count > 0)
            {
                var resposta = MessageBox.Show(
                    "A tabela atual tem dados que serão substituídos pelo registro selecionado.\n\nDeseja continuar?",
                    "Substituir conteúdo", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

                if (resposta != DialogResult.Yes)
                {
                    return;
                }
            }

            PreencherTabela(ata);

            _arquivoAberto = caminho;
            _nomeAberto = ata.Nome;
            Text = "Registrar - " + Path.GetFileName(caminho);
        }

        // Coloca cada campo do JSON na sua coluna
        private void PreencherTabela(AtaRegistro ata)
        {
            _carregandoTabela = true;
            dgvAta.Rows.Clear();

            foreach (AtaLinha linha in ata.Linhas)
            {
                int indice = dgvAta.Rows.Add();
                DataGridViewCellCollection celulas = dgvAta.Rows[indice].Cells;

                celulas[colData.Index].Value = linha.Data;
                celulas[colHorario.Index].Value = linha.Horario;
                celulas[colFato.Index].Value = linha.FatoAcontecimento;
                celulas[colEnvolvidos.Index].Value = linha.Envolvidos;
                celulas[colOperador.Index].Value = linha.OperadorGravacao;
                celulas[colStatus.Index].Value = linha.StatusObservacoes;
                if (!string.IsNullOrWhiteSpace(linha.ImagemBase64))
                    celulas[colImagem.Index].Value = DecodificarImagem(linha.ImagemBase64);
            }

            // Mantém pelo menos as linhas em branco iniciais
            for (int total = ata.Linhas.Count; total < QuantidadeLinhasIniciais; total++)
            {
                dgvAta.Rows.Add();
            }

            _carregandoTabela = false;
            if (dgvAta.Rows.Count > 0)
            {
                dgvAta.FirstDisplayedScrollingRowIndex = 0;
            }
        }

        // Lê a tabela, ignorando a linha de entrada e as linhas totalmente vazias
        private List<AtaLinha> ColetarLinhas()
        {
            var linhas = new List<AtaLinha>();

            foreach (DataGridViewRow row in dgvAta.Rows)
            {
                if (row.IsNewRow)
                {
                    continue;
                }

                var linha = new AtaLinha
                {
                    Data = TextoDa(row, colData),
                    Horario = TextoDa(row, colHorario),
                    FatoAcontecimento = TextoDa(row, colFato),
                    Envolvidos = TextoDa(row, colEnvolvidos),
                    OperadorGravacao = TextoDa(row, colOperador),
                    StatusObservacoes = TextoDa(row, colStatus),
                    ImagemBase64 = CodificarImagem(ImagemDaCelula(row.Index))
                };

                bool vazia = linha.Data.Length == 0 && linha.Horario.Length == 0 &&
                             linha.FatoAcontecimento.Length == 0 && linha.Envolvidos.Length == 0 &&
                             linha.OperadorGravacao.Length == 0 && linha.StatusObservacoes.Length == 0 &&
                             string.IsNullOrEmpty(linha.ImagemBase64);

                if (!vazia)
                {
                    linhas.Add(linha);
                }
            }

            return linhas;
        }


        private void dgvAta_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            for (int i = e.RowIndex; i < e.RowIndex + e.RowCount && i < dgvAta.Rows.Count; i++)
            {
                if (dgvAta.Rows[i].Cells[colImagem.Index].Value == null)
                    dgvAta.Rows[i].Cells[colImagem.Index].Value = _imagemVazia;
            }
        }

        private void dgvAta_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || _carregandoTabela) return;
            if (e.ColumnIndex == colImagem.Index)
                dgvAta.InvalidateCell(e.ColumnIndex, e.RowIndex);

            // Ao preencher a última linha, cria uma linha comum, não a linha especial do grid.
            if (e.RowIndex == dgvAta.Rows.Count - 1 && LinhaPossuiDados(dgvAta.Rows[e.RowIndex]))
                dgvAta.Rows.Add();
        }

        private bool LinhaPossuiDados(DataGridViewRow row)
        {
            foreach (DataGridViewCell cell in row.Cells)
            {
                if (cell.OwningColumn == colImagem)
                {
                    Image img = cell.Value as Image;
                    if (img != null && !ReferenceEquals(img, _imagemVazia) && !(img.Width <= 1 && img.Height <= 1)) return true;
                }
                else if (!string.IsNullOrWhiteSpace(Convert.ToString(cell.Value)))
                {
                    return true;
                }
            }
            return false;
        }

        private Image ImagemDaCelula(int indiceLinha)
        {
            Image imagem = dgvAta.Rows[indiceLinha].Cells[colImagem.Index].Value as Image;
            if (imagem == null || ReferenceEquals(imagem, _imagemVazia)) return null;
            // Alguns estados da grade clonam o marcador transparente; não o trate como foto.
            if (imagem.Width <= 1 && imagem.Height <= 1) return null;
            return imagem;
        }

        private void dgvAta_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            // Impede que valores nulos da coluna de imagem virem o ícone de erro padrão.
            e.ThrowException = false;
            e.Cancel = true;
        }

        // A célula vazia mostra um ícone de fotografia centralizado; só ele abre o explorador.
        private void dgvAta_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != colImagem.Index) return;

            e.PaintBackground(e.ClipBounds, true);
            Image atual = e.Value as Image;
            if (atual != null && !ReferenceEquals(atual, _imagemVazia))
            {
                // Desenha a miniatura normalmente, mas nunca deixa o placeholder vermelho aparecer.
                e.PaintContent(e.ClipBounds);
            }
            else
            {
                DesenharIconeImagem(e.Graphics, e.CellBounds);
            }
            e.Paint(e.ClipBounds, DataGridViewPaintParts.Border);
            e.Handled = true;
        }

        private static Rectangle RetanguloIconeImagem(Rectangle celula)
        {
            const int largura = 34, altura = 30;
            return new Rectangle(celula.Left + (celula.Width - largura) / 2,
                celula.Top + (celula.Height - altura) / 2, largura, altura);
        }

        private static void DesenharIconeImagem(Graphics graphics, Rectangle celula)
        {
            Rectangle area = RetanguloIconeImagem(celula);
            Color azul = Color.FromArgb(37, 99, 235);
            using (var fundo = new SolidBrush(Color.FromArgb(235, 243, 255)))
            using (var borda = new Pen(Color.FromArgb(147, 197, 253), 1f))
            using (var caneta = new Pen(azul, 2f))
            using (var pincel = new SolidBrush(azul))
            {
                graphics.FillRectangle(fundo, area);
                graphics.DrawRectangle(borda, area);
                // Ícone de fotografia: moldura, sol e montanhas.
                Rectangle foto = new Rectangle(area.Left + 8, area.Top + 7, 18, 16);
                graphics.DrawRectangle(caneta, foto);
                graphics.FillEllipse(pincel, area.Left + 20, area.Top + 10, 3, 3);
                graphics.DrawLine(caneta, area.Left + 10, area.Top + 21, area.Left + 15, area.Top + 15);
                graphics.DrawLine(caneta, area.Left + 15, area.Top + 15, area.Left + 19, area.Top + 19);
                graphics.DrawLine(caneta, area.Left + 19, area.Top + 19, area.Left + 22, area.Top + 16);
                graphics.DrawLine(caneta, area.Left + 22, area.Top + 16, area.Left + 25, area.Top + 21);
            }
        }

        private void dgvAta_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != colImagem.Index) return;
            Rectangle celula = dgvAta.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
            Rectangle icone = RetanguloIconeImagem(celula);
            Point pontoGrade = new Point(celula.Left + e.Location.X, celula.Top + e.Location.Y);
            var atual = ImagemDaCelula(e.RowIndex);
            if (atual == null)
            {
                if (icone.Contains(pontoGrade)) AbrirExploradorImagem(e.RowIndex);
                return; // fora do ícone, célula vazia apenas seleciona para Ctrl+V
            }
            using (var janela = new Form())
            using (var imagem = new PictureBox())
            {
                janela.Text = "Visualização da imagem";
                janela.StartPosition = FormStartPosition.CenterParent;
                janela.ClientSize = new Size(900, 650);
                janela.MinimumSize = new Size(400, 300);
                imagem.Dock = DockStyle.Fill;
                imagem.SizeMode = PictureBoxSizeMode.Zoom;
                imagem.Image = (Image)atual.Clone();
                janela.Controls.Add(imagem);
                janela.ShowDialog(this);
                imagem.Image.Dispose();
            }
        }

        private void AbrirExploradorImagem(int indiceLinha)
        {
            using (var dialogo = new OpenFileDialog())
            {
                dialogo.Title = "Selecione uma imagem para esta linha";
                dialogo.Filter = "Imagens|*.jpg;*.jpeg;*.png;*.bmp;*.gif|Todos os arquivos|*.*";
                if (dialogo.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    using (var original = Image.FromFile(dialogo.FileName))
                        SalvarImagemNaLinha(indiceLinha, original);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Não foi possível carregar a imagem: " + ex.Message, "Imagem", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private static bool CaminhoEhImagem(string caminho)
        {
            if (string.IsNullOrWhiteSpace(caminho) || !File.Exists(caminho)) return false;
            string extensao = Path.GetExtension(caminho).ToLowerInvariant();
            return extensao == ".jpg" || extensao == ".jpeg" || extensao == ".png" ||
                   extensao == ".bmp" || extensao == ".gif" || extensao == ".tif" || extensao == ".tiff";
        }

        private void SalvarImagemNaLinha(int indiceLinha, Image original)
        {
            using (var reduzida = Redimensionar(original, 1280, 1280))
            {
                string comprimida = CodificarImagem(reduzida);
                dgvAta.Rows[indiceLinha].Cells[colImagem.Index].Value = DecodificarImagem(comprimida);
            }
            dgvAta.Rows[indiceLinha].Height = Math.Max(dgvAta.Rows[indiceLinha].Height, 90);
        }

        private static Bitmap Redimensionar(Image imagem, int maxLargura, int maxAltura)
        {
            double escala = Math.Min(1.0, Math.Min((double)maxLargura / imagem.Width, (double)maxAltura / imagem.Height));
            int largura = Math.Max(1, (int)(imagem.Width * escala));
            int altura = Math.Max(1, (int)(imagem.Height * escala));
            var bitmap = new Bitmap(largura, altura);
            using (var g = Graphics.FromImage(bitmap))
            {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.DrawImage(imagem, 0, 0, largura, altura);
            }
            return bitmap;
        }

        private static string CodificarImagem(Image imagem)
        {
            if (imagem == null) return null;
            using (var reduzida = Redimensionar(imagem, 1280, 1280))
            using (var memoria = new MemoryStream())
            {
                var encoder = ImageCodecInfo.GetImageEncoders().First(c => c.MimeType == "image/jpeg");
                using (var parametros = new EncoderParameters(1))
                {
                    parametros.Param[0] = new EncoderParameter(Encoder.Quality, 75L);
                    reduzida.Save(memoria, encoder, parametros);
                }
                return Convert.ToBase64String(memoria.ToArray());
            }
        }

        private static Image DecodificarImagem(string base64)
        {
            byte[] bytes = Convert.FromBase64String(base64);
            using (var memoria = new MemoryStream(bytes))
            using (var imagem = Image.FromStream(memoria))
                return (Image)imagem.Clone();
        }

        private static string TextoDa(DataGridViewRow row, DataGridViewColumn coluna)
        {
            return (Convert.ToString(row.Cells[coluna.Index].Value) ?? string.Empty).Trim();
        }
    }
}
